tests_list = [
    {
        scriptUrl: "2025-may-en-1.js",
        name: "אנגלית 5/25 - 1",
        lang: 'en',
    },
    {
        scriptUrl: "2025-may-en-2.js",
        name: "אנגלית 5/25 - 2",
        lang: 'en',
    },
    {
        scriptUrl: "2025-may-en-3.js",
        name: "אנגלית 5/25 - 3",
        lang: 'en',
    },
    {
        scriptUrl: "2025-may-en-4.js",
        name: "אנגלית 5/25 - 4",
        lang: 'en',
    },
    {
        scriptUrl: "2025-may-en-5.js",
        name: "אנגלית 5/25 - 5",
        lang: 'en',
    },
    {
        scriptUrl: "2025-mar-fr-1.js",
        name: "צרפתית 3/25 - 1",
        lang: 'fr',
    },
    {
        scriptUrl: "2025-mar-fr-2.js",
        name: "צרפתית 3/25 - 2",
        lang: 'fr',
    },
    {
        scriptUrl: "2025-mar-fr-3.js",
        name: "צרפתית 3/25 - 3",
        lang: 'fr',
    },
    {
        scriptUrl: "2025-mar-fr-4.js",
        name: "צרפתית 3/25 - 4",
        lang: 'fr',
    },
    {
        scriptUrl: "2024-dec-en.js",
        name: "אנגלית 12/24",
        lang: 'en',
    },
    {

        scriptUrl: "2024-nov-fr-1.js",
        name: "צרפתית 11/24 - 1",
        lang: 'fr',
    },
    {

        scriptUrl: "2024-nov-fr-2.js",
        name: "צרפתית 11/24 - 2",
        lang: 'fr',
    },
    {

        scriptUrl: "2024-nov-fr-3.js",
        name: "צרפתית 11/24 - 3",
        lang: 'fr',
    },

    {

        scriptUrl: "2024-nov-en-1.js",
        name: "אנגלית 11/24 - 1",
        lang: 'en',
    },
    {

        scriptUrl: "2024-nov-en-2.js",
        name: "אנגלית 11/24 - 2",
        lang: 'en',
    },
    {

        scriptUrl: "2024-nov-en-3.js",
        name: "אנגלית 11/24 - 3",
        lang: 'en',
    },
    {

        scriptUrl: "2024-oct-fr.js",
        name: "צרפתית 10/24",
        lang: 'fr',
    },

];